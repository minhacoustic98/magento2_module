<?php

namespace Blog\Contact\Model;

use Blog\Contact\Api\Data\ContactInterface;

class Contact extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface,ContactInterface
{
    const CACHE_TAG='blog_contact_contact';
    
    protected $_cacheTag='blog_contact_contact';

    protected $_eventPrefix='blog_contact_contact';

    protected function _construct()
    {
        $this->_init('Blog\Contact\Model\ResourceModel\Contact');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG.'_'.$this->getId()];
    }

    public function getDefaultValues()
    {
        $values=[];
        return $values;
    }

}