<?php
namespace Blog\Contact\Model\ResourceModel\Contact;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName='contact_id';
    protected $_eventPrefix='blog_contact_contact_collection';
    protected $_eventObject='contact_collection';

    /**
     * Define resource model
     * 
     * @return void
     */

     public function _construct()
     {
         $this->_init('Blog\Contact\Model\Contact','Blog\Contact\Model\ResourceModel\Contact');
     }
}