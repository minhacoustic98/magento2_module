<?php

namespace Blog\Contact\Model;

use Blog\Contact\Api\Data;
use Blog\Contact\Api\ContactRepositoryInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use Blog\Contact\Model\ResourceModel\Contact as ResourceContact;
use Blog\Contact\Model\ResourceModel\Contact\CollectionFactory as ContactCollectionFactory;


/**
 * Class ContactRepository
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */

 class ContactRepository implements ContactRepositoryInterface
 {
     /**
      * @var ResourceContact
      * use ResourceModel
      */
      protected $resource;

      /**
       * @var ContactFactory
       * use Model
       */
      protected $ContactFactory;

      /**
       * @var ContactCollectionFactory
       * use collection
       */
      protected $ContactCollectionFactory;

      /**
       * @var Data\ContactSearchResultsInterfaceFactory
       */
      protected $selectResultsFactory;
      /**
       * @param ResourceContact $resource
       * @param ContactFactory $ContactFactory
       * @param Data\ContactInterfaceFactory $dataContactFactory
       * @param Data\ContactResultsInterfaceFactory $searchResultsFactory
       * 
       */
      private $collectionProcessor;

      public function __construct(
          ResourceContact $resource,
          ContactFactory $ContactFactory,
          Data\ContactInterfaceFactory $dataContactFactory,
          ContactCollectionFactory $ContactCollectionFactory
      )
      {
          $this->resource=$resource;
          $this->ContactFactory=$ContactFactory;
          $this->ContactCollectionFactory=$ContactCollectionFactory;
      }

      /**
       * Save Contact Data
       * @param \Blog\Contact\Api\Data\ContactInterface $Contact
       * @return Contact
       * @throws CouldNotSaveException
       */

       public function save(\Blog\Contact\Api\Data\ContactInterface $Contact)
       {
          try{
                $this->resource->save($Contact);
          }catch(\Exception $exception)
          {
            throw new CouldNotSaveException(
                __('Could not save the contact :%1',$exception->getMessage(),$exception)
            );
          }
       }


        /**
      * Load Contact data by given Contact indentity
      * @param string $ContactID
      * @return Contact
      * @throws \Magento\Framework\Exception\NoSuchEntityException
      */


       public function getById($ContactId)
       {
           $Contact=$this->ContactFactory->create();
           $Contact->load($ContactId);
           if(!$Contact->getId())
           {
               throw new NoSuchEntityException(__('The CMS width id:%1 doesn\'t exists.',$ContactId));

           }
           return $Contact;
       }

       /**
        * Delete the specific Contact
        * @param \Blog\Contact\Api\Data\ContactInterface;
        * @return true on success
        * @throws CouldNotDeleteException
        */

        public function delete(\Blog\Contact\Api\Data\ContactInterface $Contact)
        {
            try{
                $this->resource->delete($Contact);
            }catch(\Exception $exception){
                throw new CouldNotDeleteException(
                    __('Could not delete Contact ID:%1',$exception->getMessage(),$exception)
                );
            }
            return true;
        }

        /**
         * Get collection of ContactModel
         * @return \Blog\Contact\Model\ResourceModel\Contact\Collection
         */

         public function getCollection()
         {
            $collection=$this->ContactCollectionFactory->create();
            return $collection;
         }

         public function deleteById($ContactID)
         {
             return $this->delete($this->getById($ContactID));
         }



 }