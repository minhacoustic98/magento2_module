<?php
namespace Blog\Contact\Api\Data;

interface ContactInterface
{
    
}