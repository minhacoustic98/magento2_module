<?php
namespace Blog\Contact\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ContactRepositoryInterface
{
    /**
     * Save the contact
     * Process for create and edit
     * 
     * @param \Blog\Contact\Api\Data\ContactInterface $ContactInterface
     * @return \Blog\Contact\Api\Data\ContactInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */

     public function save(\Blog\Contact\Api\Data\ContactInterface $Contact);
    
     /**
      * Retrieve Contact matching the specified criteria.
      *
      *@param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Blog\Contact\Api\Data\ContactSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
      */

    
      
    public function getById($ContactId);

    /**
     * Delete Post.
     * 
     * @param \Blog\Contact\Api\Data\ContactInterface $Contact
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */

     public function delete(\Blog\Contact\Api\Data\ContactInterface $Contact);

     /**
      * Delete Contact by ID.
      * @param int $ContactID
      * @return bool true on success
      * @throws \Magento\Framework\Exception\NoSuchEntityException
      * @throws \Magento\Framework\Exception\LocalizedException
      */

      public function deleteById($ContactID);
}
