<?php
 
namespace Exercise\Testimonial\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Exercise\Testimonial\Model\TestFactory;

class Save extends \Magento\Framework\App\Action\Action
{
    protected $_test;
    protected $imageUploader;
 
    public function __construct(
        Context $context,
        TestFactory $test,
        \Exercise\Testimonial\Model\ImageUploader $imageUpload
    ) {
        $this->_test = $test;
        $this->imageUploader=$imageUpload;
        parent::__construct($context);
    }
    public function execute()
    {
        $data = $this->getRequest()->getParams();
        
        if(isset($_FILES['avatar']['name']) && $_FILES['avatar']['name'] != '') {
           $imgInfo=$this->imageUploader->saveFileToTmpDir('avatar');
           $data['avatar']=$imgInfo['name'];
        }
        $test = $this->_test->create();
        $test->setData($data);
        if($test->save()){
            $this->messageManager->addSuccessMessage(__('You saved the data.'));
        }else{
            $this->messageManager->addErrorMessage(__('Data was not saved.'));
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('test');
        return $resultRedirect;
    }
}