<?php
namespace Exercise\Testimonial\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;

    protected $_testFactory;
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Exercise\Testimonial\Model\TestFactory $testFactory
    )
    {
        $this->_pageFactory=$pageFactory;
        $this->_testFactory=$testFactory;
        return parent::__construct($context);
    }

    public function execute()
    {
       
       return $this->_pageFactory->create(); //return page
    }
}