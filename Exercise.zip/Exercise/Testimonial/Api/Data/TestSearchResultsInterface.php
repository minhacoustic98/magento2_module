<?php
namespace Exercise\Testimonial\Api\Data;

interface TestSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Testimonial list.
     * @return \Exercise\Testimonial\Api\Data\TestInterface[]
     */
    public function getItems();

    /**
     * Set name list.
     * @param \Exercise\Testimonial\Api\Data\TestInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}