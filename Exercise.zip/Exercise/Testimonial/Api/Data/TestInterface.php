<?php
namespace Exercise\Testimonial\Api\Data;

interface TestInterface
{
    
}
