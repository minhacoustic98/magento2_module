<?php
namespace Exercise\Testimonial\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface TestRepositoryInterface
{
    /**
     * Save the testimonial
     * Process for create and edit
     * 
     * @param \Exercise\Testimonial\Api\Data\TestInterface $TestInterface
     * @return \Exercise\Testimonial\Api\Data\TestInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */

     public function save(\Exercise\Testimonial\Api\Data\TestInterface $TestInterface);
    
     /**
      * Retrieve Testimonial matching the specified criteria.
      *
      *@param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Exercise\Testimonial\Api\Data\TestInterface
     * @throws \Magento\Framework\Exception\LocalizedException
      */

    
      
    public function getById($TestimonialID);

    /**
     * Delete Testimonial.
     * 
     * @param \Exercise\Testimonial\Api\Data\TestInterface $Test
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */

     public function delete(\Exercise\Testimonial\Api\Data\TestInterface $Test);

     /**
      * Delete Testimonial by ID.
      * @param int $TestimonialID
      * @return bool true on success
      * @throws \Magento\Framework\Exception\NoSuchEntityException
      * @throws \Magento\Framework\Exception\LocalizedException
      */

      public function deleteById($TestimonialID);
}
