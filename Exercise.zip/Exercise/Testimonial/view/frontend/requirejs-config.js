var config={
    map:{
        '*':{
            slick:'Exercise_Testimonial/js/slick'
        }
    }
};