<?php
namespace Exercise\Testimonial\Model;

use Exercise\Testimonial\Api\Data\TestInterface;
class Test extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface,TestInterface
{
    /**
     * define 3 variables:CACHE_TAG,_cacheTag,eventPrefix
     * name=vendor_module[name]_action
     */

     const CACHE_TAG='exercise_testimonial_test';

     protected $_cacheTag='exercise_testimonial_test';

     protected $_eventPrefix='exercise_testimonial_test';

     protected function _construct()
     {
         $this->_init('Exercise\Testimonial\Model\ResourceModel\Test');
     }

     public function getIdentities()
     {
         return [self::CACHE_TAG.'_'.$this->getId()];
     }

     public function getDefaultValues()
     {
         $values=[];
         return $values;
     }
}