<?php
namespace Exercise\Testimonial\Model\Test;

use Exercise\Testimonial\Model\ResourceModel\Test\CollectionFactory;
use Exercise\Testimonial\Model\Test;
use Magento\Store\Model\StoreManagerInterface;
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    protected $collection;
    protected $_loadedData;
    protected $storeManager;
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $testCollectionFactory,
        array $meta = [],
        array $data = [],
        StoreManagerInterface $storeManager
    ){
        $this->collection = $testCollectionFactory->create();
        $this->storeManager=$storeManager;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if(isset($this->_loadedData)) {
            return $this->_loadedData;
        }

        $items = $this->collection->getItems();

        foreach($items as $test)
        {
            $this->_loadedData[$test->getId()] = $test->getData();
            if ($test->getAvatar()) {
                $m['avatar'][0]['name'] = $test->getAvatar();
                $m['avatar'][0]['url'] = $this->getMediaUrl().$test->getAvatar();
                $fullData = $this->_loadedData;
                $this->_loadedData[$test->getId()] = array_merge($fullData[$test->getId()], $m);
            }
        }

        return $this->_loadedData;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'faq/tmp/icon/';
        return $mediaUrl;
    }
}