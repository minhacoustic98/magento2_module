<?php
namespace Exercise\Testimonial\Model\Source;

class Values implements \Magento\Framework\Option\ArrayInterface{
    public function toOptionArray()
    {
        return [
            ['value' => 0, 'label' => __('Aproved')],
            ['value' => 1, 'label' => __('Pending')],
          
        ];
    }
}