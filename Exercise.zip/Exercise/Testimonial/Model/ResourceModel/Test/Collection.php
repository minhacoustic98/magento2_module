<?php
namespace Exercise\Testimonial\Model\ResourceModel\Test;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define 3 variable: _idFieldName->primary_field
     * _eventPrefix:vendor_module[name]_action_collection
     * _eventObject:action_collection
     */

     protected $_idFieldName='test_id';

     protected $_eventPrefix='exercise_testimonial_test_collection';

     protected $_eventObject='test_collection';

     protected function _construct()
     {
         $this->_init('Exercise\Testimonial\Model\Test','Exercise\Testimonial\Model\ResourceModel\Test');
     }
}