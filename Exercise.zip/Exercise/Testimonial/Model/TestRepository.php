<?php

namespace Exercise\Testimonial\Model;

use Exercise\Testimonial\Api\Data;
use Exercise\Testimonial\Api\TestRepositoryInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use Exercise\Testimonial\Model\ResourceModel\Test as ResourceTest;
use Exercise\Testimonial\Model\ResourceModel\Test\CollectionFactory as TestCollectionFactory;


/**
 * Class TestRepository
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */

 class TestRepository implements TestRepositoryInterface
 {
     /**
      * @var ResourceTest
      * use ResourceModel
      */
      protected $resource;

      /**
       * @var TestFactory
       * use Model
       */
      protected $TestFactory;

      /**
       * @var TestCollectionFactory
       * use collection
       */
      protected $TestCollectionFactory;

      /**
       * @var Data\TestSearchResultsInterfaceFactory
       */
      protected $selectResultsFactory;
      /**
       * @param ResourceTest $resource
       * @param TestFactory $TestFactory
       * @param Data\TestInterfaceFactory $dataTestFactory
       * @param Data\TestResultsInterfaceFactory $searchResultsFactory
       * 
       */
      private $collectionProcessor;

      public function __construct(
          ResourceTest $resource,
          TestFactory $TestFactory,
          Data\TestInterfaceFactory $dataTestFactory,
          TestCollectionFactory $TestCollectionFactory
      )
      {
          $this->resource=$resource;
          $this->TestFactory=$TestFactory;
          $this->TestCollectionFactory=$TestCollectionFactory;
      }

      /**
       * Save Test Data
       * @param \Exercise\Testimonial\Api\Data\TestInterface $Test
       * @return Test
       * @throws CouldNotSaveException
       */

       public function save(\Exercise\Testimonial\Api\Data\TestInterface $Test)
       {
          try{
                $this->resource->save($Test);
          }catch(\Exception $exception)
          {
            throw new CouldNotSaveException(
                __('Could not save the Test :%1',$exception->getMessage(),$exception)
            );
          }
       }


        /**
      * Load Test data by given Test indentity
      * @param string $TestID
      * @return Test
      * @throws \Magento\Framework\Exception\NoSuchEntityException
      */


       public function getById($TestId)
       {
           $Test=$this->TestFactory->create();
           $Test->load($TestId);
           if(!$Test->getId())
           {
               throw new NoSuchEntityException(__('The CMS width id:%1 doesn\'t exists.',$TestId));

           }
           return $Test;
       }

       /**
        * Delete the specific Test
        * @param \Exercise\Testimonial\Api\Data\TestInterface;
        * @return true on success
        * @throws CouldNotDeleteException
        */

        public function delete(\Exercise\Testimonial\Api\Data\TestInterface $Test)
        {
            try{
                $this->resource->delete($Test);
            }catch(\Exception $exception){
                throw new CouldNotDeleteException(
                    __('Could not delete Test ID:%1',$exception->getMessage(),$exception)
                );
            }
            return true;
        }

        /**
         * Get collection of TestModel
         * @return \Exercise\Testimonial\Model\ResourceModel\Test\Collection
         */

         public function getCollection()
         {
            $collection=$this->TestCollectionFactory->create();
            return $collection;
         }

         public function deleteById($TestID)
         {
             return $this->delete($this->getById($TestID));
         }



 }