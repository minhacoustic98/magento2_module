<?php

namespace Exercise\Testimonial\Block;

use Exercise\Testimonial\Model\Test\DataProvider;
class Index extends \Magento\Framework\View\Element\Template
{
    
    private $testFactory;
    private $testRepository;
    protected $storeManager;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Exercise\Testimonial\Model\TestFactory $testFactory,
        \Exercise\Testimonial\Model\TestRepository $testRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    )
    {
        parent::__construct($context);
        $this->testFactory=$testFactory;
        $this->testRepository=$testRepository;
        $this->storeManager=$storeManager;
    }
     
    public function getTestList(){
        return $this->testRepository->getCollection();
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

        return $mediaUrl;
    }
    public function getInfo(){
        return __('Minh');
    }
    
}