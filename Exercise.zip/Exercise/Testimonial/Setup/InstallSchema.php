<?php
namespace Exercise\Testimonial\Setup;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
    public function install(\Magento\Framework\Setup\SchemaSetupInterface $setup, \Magento\Framework\Setup\ModuleContextInterface $context)
    {
        $installer=$setup;
        $installer->startSetup();

        if(!$installer->tableExists('testimonial'))
        {
           $table=$installer->getConnection()->newTable(
               $installer->getTable('testimonial')
           )
           ->addColumn(
               'test_id',
               \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
               null,
               [
                   'identity'=>true,
                   'nullable'=>false,
                   'primary'=>true,
                   'unsigned'=>true
               ],
               'Testimonial ID'
           )
           ->addColumn(
               'name',
               \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
               255,
               [
                    'nullable=>false'
               ],
               'Name of Client'
           )
           ->addColumn(
               'email',
               \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
               255,
               [
                   'nullable'=>false
               ],
               'Email of Client'
           )

           ->addColumn(
               'desgination',
               \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
               255,
               [
                    'nullable'=>false
               ],
               'Desgination'
           )

           ->addColumn(
               'contact',
               \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
               255,
               ['nullable'=>false],
               'Contact'
           )
           
           ->addColumn(
               'message',
               \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
               255,
               ['nullable'=>false],
               'Message'
           )

           ->addColumn(
               'avatar',
               \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
               255,
               ['nullable'=>false],
               'Avatar'
           )

           ->addColumn(
               'created_at',
               \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
               null,
               ['nullable'=>false,'default'=>\Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
               'Created at'
           )

           ->addColumn(
               'updated_at',
               \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
               null,
               ['nullable'=>false,'default'=>\Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE],
               'Updated at'
           )

           ->addColumn(
               'is_enable',
               \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
               null,
               ['nullable'=>false,'default'=>'1'],
               'Is Enabled'
           )
           ->setComment('Testimonial Table');

          $installer->getConnection()->createTable($table);

          $installer->getConnection()->addIndex(
              $installer->getTable('testimonial'),
              $setup->getIdxName(
                  $installer->getTable('testimonial'),
                  ['name','message','avatar'],
                  \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
              ),
              ['name','message','avatar'],
              \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
            );
        }

        $installer->endSetup();
    }
}